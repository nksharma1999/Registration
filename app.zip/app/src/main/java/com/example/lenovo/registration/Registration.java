package com.example.lenovo.registration;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {
    private Data mydata;
    EditText email,password,cpassword;
    Button ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        mydata=new Data(this);
        email=(EditText)findViewById(R.id.editText_email);
        password=(EditText)findViewById(R.id.editText4_password);
        cpassword=(EditText)findViewById(R.id.editText5_cpassword);
        ok=(Button) findViewById(R.id.button_ok);
        Cursor res2 = mydata.get();
        if (res2.getCount()>0){
            Intent intent8=new Intent(Registration.this,DS.class);
            startActivity(intent8);
        }
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=email.getText().toString();
                String s2=password.getText().toString();
                String s3=cpassword.getText().toString();
                if(s1.equals("")||s2.equals("")||s3.equals("")){
                    Toast.makeText(Registration.this,"Please fill all",Toast.LENGTH_LONG).show();
                }
                else{
                    if (s2.equals(s3)){
                        Boolean chkemail=mydata.chkemail(s1);
                        if (chkemail==true){
                            Boolean insert=mydata.insert(s1,s2);
                            Toast.makeText(Registration.this,"Registered Successfully",Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(Registration.this,DS.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(Registration.this,"Email Already Exists",Toast.LENGTH_LONG).show();
                            Intent intent5=new Intent(Registration.this,DS.class);
                            startActivity(intent5);

                        }
                    }
                    else {
                        Toast.makeText(Registration.this,"Password do not match",Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

    }
}
