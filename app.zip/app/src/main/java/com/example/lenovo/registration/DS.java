package com.example.lenovo.registration;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DS extends AppCompatActivity {
    private Store_data mydata;
    EditText name,phone,email,data;
    Button add,show,search,delete,edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ds);
        mydata=new Store_data(this);
        name=(EditText)findViewById(R.id.editText_name2);
        phone=(EditText)findViewById(R.id.editText3_phone);
        email=(EditText)findViewById(R.id.editText4_Email);
        data=(EditText)findViewById(R.id.editText5_text);
        add=(Button)findViewById(R.id.button_add);
        show=(Button)findViewById(R.id.button2_show);
        search=(Button)findViewById(R.id.button3_search);
        delete=(Button)findViewById(R.id.button4_delete);
        edit=(Button)findViewById(R.id.button5_edit);
        //view();
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=name.getText().toString();
                String s2=phone.getText().toString();
                String s3=email.getText().toString();
                String s4=data.getText().toString();
                if(s1.equals("")||s2.equals("")||s3.equals("")||s4.equals("")){
                    Toast.makeText(DS.this,"Please fill all",Toast.LENGTH_LONG).show();
                }else {
                    Boolean chkemail1 = mydata.chkemail1(s1);
                    if (chkemail1==true) {
                        Boolean insert = mydata.insert1(s1, s2,s3,s4);
                        Toast.makeText(DS.this, "Add Successfully", Toast.LENGTH_LONG).show();
                        name.setText("");
                        phone.setText("");
                        email.setText("");
                        data.setText("");
                    } else {
                        Toast.makeText(DS.this, "Name Already Exists", Toast.LENGTH_LONG).show();
                        Intent intent=new Intent(DS.this,DS.class);
                        startActivity(intent);
                    }
                }
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(DS.this,search.class);
                startActivity(intent);
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(DS.this,Edit.class);
                startActivity(intent3);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(DS.this,Delete.class);
                startActivity(intent2);
            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(DS.this,Listview.class);
                startActivity(intent);
                /*Cursor res=mydata.getstoredata();
                if(res.getCount()==0){
                    showMessage("Error","Nothing found");
                    return;}
                StringBuffer buffer1=new StringBuffer();
                while (res.moveToNext()){
                    //if(res.getString(0).equals(id2.getText().toString())) {
                    buffer1.append("Name:-" + res.getString(0) + "\n");
                    buffer1.append("Phone :-" + res.getString(1) + "\n");
                    buffer1.append("Email :-" + res.getString(2) + "\n");
                    buffer1.append("Data :-" + res.getString(3) + "\n");
                    //showMessage("Data",buffer1.toString());
                    //break;
                    //}
                }
                showMessage("Data",buffer1.toString());
                // if (!res.getString(0).equals(id2.getText().toString())) {
                //  showMessage("Error", "Nothing found");
                //  }
                //showMessage("Data",buffer1.toString());*/


            }
        });
    }
   // public void view(){

   // }
   /* public void showMessage(String title,String Message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();

    }*/
}
