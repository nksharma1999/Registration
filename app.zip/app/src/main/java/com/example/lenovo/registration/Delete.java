package com.example.lenovo.registration;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Delete extends AppCompatActivity {
    private Store_data mydata;
    EditText name;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        mydata=new Store_data(this);
        name=(EditText)findViewById(R.id.editText_name2);
        btn=(Button)findViewById(R.id.button_delete);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().equals("")){
                    Toast.makeText(Delete.this,"Enter Name",Toast.LENGTH_LONG).show();
                }else {
                    Boolean ch=mydata.chkemail1(name.getText().toString());
                    if (ch==false) {
                        Integer isdelete= mydata.DeleteData(name.getText().toString());
                        if (isdelete>0)
                            Toast.makeText(Delete.this,"Data Deleted",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(Delete.this,"Data Not Deleted OR Allready Deleted",Toast.LENGTH_LONG).show();

                    }else {
                        Toast.makeText(Delete.this,"Enter Valid Name",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}
