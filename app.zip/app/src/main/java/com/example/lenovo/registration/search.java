package com.example.lenovo.registration;

import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class search extends AppCompatActivity {
    private Store_data mydata;
    EditText name;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mydata=new Store_data(this);
        name=(EditText)findViewById(R.id.editText_name2);
        btn=(Button)findViewById(R.id.button_ok);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().equals("")){
                    Toast.makeText(search.this,"Enter Name",Toast.LENGTH_LONG).show();
                }else {
                    Boolean ch=mydata.chkemail1(name.getText().toString());
                    if (ch==false) {
                        Cursor res1 = mydata.getstoredata();
                        StringBuffer buffer1 = new StringBuffer();
                        while (res1.moveToNext()) {
                            if (res1.getString(0).equals(name.getText().toString())){
                            buffer1.append("Name:-" + res1.getString(0) + "\n");
                            buffer1.append("Phone :-" + res1.getString(1) + "\n");
                            buffer1.append("Email :-" + res1.getString(2) + "\n");
                            buffer1.append("Data :-" + res1.getString(3) + "\n");
                            showMessage("Data", buffer1.toString());
                            }
                        }
                    }
                    else {
                        Toast.makeText(search.this,"Enter valid Name",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();

    }
}
