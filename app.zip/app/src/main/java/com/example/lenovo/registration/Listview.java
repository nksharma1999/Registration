package com.example.lenovo.registration;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ActionMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Listview extends AppCompatActivity {
    private static final int REQUEST_CALL=1;
    private Store_data mydata;
    private ArrayAdapter Adapter;
    final ArrayList<String> thelist=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);
        ListView listView = (ListView) findViewById(R.id.listView_all);
        EditText filter=(EditText)findViewById(R.id.searchFilter);
        mydata = new Store_data(this);


        Cursor data= mydata.getListContents();
        if(data.getCount()==0){
            Toast.makeText(Listview.this, "Empty", Toast.LENGTH_LONG).show();
        }else {
            while (data.moveToNext()){
                thelist.add(data.getString(0));
                //thelist.add(data.getString(1));
                Adapter= new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,thelist);
                listView.setAdapter(Adapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Cursor res1 = mydata.getstoredata();
                    String s;
                    String call,sendemail;
                    StringBuffer buffer1 = new StringBuffer();
                    while (res1.moveToNext()) {
                        if (res1.getString(0).equals(thelist.get(position))){
                            s=res1.getString(0);
                            call=res1.getString(1);
                            sendemail=res1.getString(2);
                            buffer1.append("Name:- " + res1.getString(0) + "\n\n");
                            buffer1.append("Phone :-  " + res1.getString(1) + "\n\n");
                            buffer1.append("Email :-" + res1.getString(2) + "\n\n");
                            buffer1.append("Information:- \n" + res1.getString(3) + "\n");
                            showMessage("Data", buffer1.toString(),s,call,sendemail);
                        }
                        Adapter.notifyDataSetChanged();
                    }

                }
            });
            filter.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    (Listview.this).Adapter.getFilter().filter(s);

                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });

            }
        }

    }
    private String callnumber="";
    private void Callfunction(){
        String number=callnumber;
        if(number.trim().length()>0){
            if(ContextCompat.checkSelfPermission(Listview.this,Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(Listview.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
            }else{
                String dial ="tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL , Uri.parse(dial)));
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
       if(requestCode==REQUEST_CALL){
           if(grantResults.length>0 && grantResults[0]==getPackageManager().PERMISSION_GRANTED){
               Callfunction();
           }else{
               Toast.makeText(this,"Permision Denied",Toast.LENGTH_LONG).show();
           }
       }
    }

    public void showMessage(String title, final String Message, final String s, final  String call,final String sendemail){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        //callnumber =call;
        builder.setNeutralButton("call", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callnumber =call;
                Callfunction();
            }
        });

        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Integer isdelete= mydata.DeleteData(s.toString());
                if (isdelete>0) {
                    Adapter.notifyDataSetChanged();
                    Toast.makeText(Listview.this, "Data Deleted", Toast.LENGTH_LONG).show();

                }else
                    Toast.makeText(Listview.this,"Data Not Deleted OR Allready Deleted",Toast.LENGTH_LONG).show();

            }
        });
        builder.setNegativeButton("Email", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String[] TO_EMAILS={sendemail};
                Intent intent=new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL,TO_EMAILS);
                startActivity(Intent.createChooser(intent,"Choose one application:"));

            }
        });
        builder.setMessage(Message);
        builder.show();
    }


}
