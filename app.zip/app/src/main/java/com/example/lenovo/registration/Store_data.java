package com.example.lenovo.registration;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class Store_data extends SQLiteOpenHelper {
    public Store_data(Context context) {
        super(context, "ds.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table stud1(name text primary key,phone text,email text,data text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists stud");
    }
    public boolean insert1(String name,String phone,String email,String data){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        contentValues.put("email",email);
        contentValues.put("data",data);
        long ins=db.insert("stud1",null,contentValues);
        if(ins==-1)return false;
        else return true;
    }
    public boolean chkemail1(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from stud1 where name=?",new String[]{name});
        if (cursor.getCount()>0)return false;
        else return true;
    }
    public Cursor getstoredata(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from stud1",null);
        return res;
    }
    public Cursor getListContents(){
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor data =db.rawQuery("SELECT name from stud1 ",null);
        return data;
    }
    public Integer DeleteData(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        return db.delete("stud1","name=?",new String[]{id});
    }
    public boolean updateData(String id,String name, String surname, String marks){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("name",id);
        contentValues.put("phone",name);
        contentValues.put("email",surname);
        contentValues.put("data",marks);
        db.update("stud1",contentValues,"name=?",new String[]{id});
        return true;
    }
}
