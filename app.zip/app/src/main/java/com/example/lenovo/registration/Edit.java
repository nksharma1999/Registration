package com.example.lenovo.registration;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Edit extends AppCompatActivity {
    private Store_data mydata;
    EditText name,phone,email,data;
    Button ok,edit;
    String p;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        mydata=new Store_data(this);
        name=(EditText)findViewById(R.id.editText_name3);
        phone=(EditText)findViewById(R.id.editText4_phone2);
        email=(EditText)findViewById(R.id.editText5_email2);
        data=(EditText)findViewById(R.id.editText6_data2);
        ok=(Button)findViewById(R.id.button2_ok2);
        edit=(Button)findViewById(R.id.button_edit2);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.equals("")){
                    Toast.makeText(Edit.this,"Enter Name",Toast.LENGTH_LONG).show();
                }else{
                    Boolean ch=mydata.chkemail1(name.getText().toString());
                    if (ch==false) {
                        Cursor res1 = mydata.getstoredata();
                       // StringBuffer buffer1 = new StringBuffer();
                        while (res1.moveToNext()) {
                            if (res1.getString(0).equals(name.getText().toString())){
                                phone.setText(res1.getString(1));
                                email.setText(res1.getString(2));
                                data.setText(res1.getString(3));
                                p=res1.getString(0);
                            }
                        }
                    }
                    else {
                        Toast.makeText(Edit.this,"Enter valid Name",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=name.getText().toString();
                String s2=phone.getText().toString();
                String s3=email.getText().toString();
                String s4=data.getText().toString();
                if (s1.equals("")||s2.equals("")||s3.equals("")||s4.equals("")){
                    Toast.makeText(Edit.this,"Enter Name Then Edit Data",Toast.LENGTH_LONG).show();
                }else {
                if (p.equals(s1)) {
                Boolean insert = mydata.updateData(s1,s2,s3,s4);
                if (insert==true){
                    Toast.makeText(Edit.this,"Data Edited",Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(Edit.this,"Data Not Edited",Toast.LENGTH_LONG).show();
                } }else {
                    Toast.makeText(Edit.this,"Not Change Name",Toast.LENGTH_LONG).show();
                }
            }}
        });
    }
}
